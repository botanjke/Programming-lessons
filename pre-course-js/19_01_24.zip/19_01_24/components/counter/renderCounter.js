import { decreaseDataCount, increaseDataCount } from "../../data/data.js";
// import { ButtonDec } from "./buttons/ButtonDec.js";
// import { ButtonInc } from "./buttons/ButtonInc.js";
import { Button } from "./buttons/Button.js";
import { Header } from "./header/Header.js"
import { Value } from "./value/Value.js";



export function renderCounter() {
    document.body.innerHTML = ""
    // Header
    const header = Header();
    document.body.append(header)
    // Value
    const value = Value()
    document.body.append(value)
    // Buttons
    // document.body.append(ButtonInc())
    // document.body.append(ButtonDec())
    document.body.append(Button("+", increaseDataCount))
    document.body.append(Button("-", decreaseDataCount))

}