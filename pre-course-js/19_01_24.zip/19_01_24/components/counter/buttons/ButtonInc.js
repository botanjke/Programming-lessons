import { increaseDataCount } from "../../../data/data.js";

export function ButtonInc() {
    const btnElement = document.createElement("button");
    btnElement.append("+");
    btnElement.addEventListener("click", onClickCallback)
    return btnElement;
}

function onClickCallback() {
    increaseDataCount()
}