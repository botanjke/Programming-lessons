export function Button(title, func) {
    function onClickCallback() {
        func()
    }
    const btnElement = document.createElement("button");
    btnElement.append(title);
    btnElement.addEventListener("click", onClickCallback)
    return btnElement;
}

