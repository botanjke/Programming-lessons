export const data = {
    title: "Counter",
    count: 0
}

let callback = function () {
    alert("Колбэка пока нет")
};

export function setChangeDataCallback (newCallback){
    callback = newCallback
}

export function increaseDataCount(){  
    data.count++;
    // renderCounter(data);
    callback()
}
export function decreaseDataCount(){  
    data.count--;
    // renderCounter(data);
    callback()
}

// setInterval(changeData, 1000);







