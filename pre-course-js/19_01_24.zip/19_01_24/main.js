import { renderCounter } from "./components/counter/renderCounter.js";
import { setChangeDataCallback } from "./data/data.js";
// import { data } from "./data/data.js";

renderCounter();
setChangeDataCallback(renderCounter);